<?php
	session_start();
	require_once '../config/connect.php';
	if(!isset($_SESSION['email']) & empty($_SESSION['email'])){
		header('location: login.php');
	}
?>
<?php include 'inc/header.php'; ?>
<?php include 'inc/nav.php'; ?>
	
<section id="content">
	<div class="content-blog">
		<div class="container">
			<table class="table table-striped">
				<thead>
					<tr>
						<th>#</th>
						<th>Customer FirstName/Last Name</th>
			             <th>Product Name/Quantity</th>
						<th>Date & Time</th>
						<th>Total Price</th>
						<th>Ammount Paid</th>
						<th>Payment Status</th>
						<th>txn-id</th>
						<th>card number</th>
						<th>card expiry month</th>
						<th>card expiry year</th>
						
						
						
					</tr>
				</thead>
				<tbody>
				<?php 	
					$sql = "SELECT * FROM pay3 ";
					$res = mysqli_query($connection, $sql); 
					while ($r = mysqli_fetch_assoc($res)) {
				?>
					<tr>
						<th scope="row"><?php echo $r['id']; ?></th>
						<td><?php echo $r['name'] ; ?></td>
						<td><?php echo $r['productname']; ?></td>
						<td><?php echo $r['created']; ?></td>
						<td><?php echo $r['item_price']; ?></td>
                        <td><?php echo $r['paid_amount']; ?></td>
                         <td><?php echo $r['payment_status']; ?></td>
                          <td><?php echo $r['txn_id']; ?></td>
                         <td><?php echo $r['card_number']; ?></td>
                          <td><?php echo $r['card_exp_month']; ?></td>
                           <td><?php echo $r['card_exp_year']; ?></td>
                      
                      </tr>

						
				<?php } ?>
				</tbody>
			</table>
			
		</div>
	</div>

</section>
<?php include 'inc/footer.php' ?>
