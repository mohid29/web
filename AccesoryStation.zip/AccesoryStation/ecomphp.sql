-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 13, 2020 at 04:13 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecomphp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `firstname`, `lastname`, `email`, `password`) VALUES
(1, 'Vivek', 'Vengala', 'vivek@codingcyber.com', '26e0eca228b42a520565415246513c0d'),
(2, 'mohid', 'naz', 'mohid5762@gmail.com', 'ff45ffad5466a0d0cab7e27d4028734a');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'Mobiles'),
(2, 'Cameras'),
(3, 'Books'),
(4, 'Fruits');

-- --------------------------------------------------------

--
-- Table structure for table `orderitems`
--

CREATE TABLE `orderitems` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `pquantity` varchar(255) NOT NULL,
  `orderid` int(11) NOT NULL,
  `productprice` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderitems`
--

INSERT INTO `orderitems` (`id`, `pid`, `pquantity`, `orderid`, `productprice`) VALUES
(1, 19, '5', 1, '16'),
(2, 19, '5', 2, '16'),
(3, 1, '2', 2, '20990'),
(4, 1, '1', 3, '20990'),
(5, 20, '10', 3, '99'),
(6, 18, '1', 4, '12890'),
(7, 21, '1', 4, '75'),
(8, 2, '1', 5, '7590'),
(9, 19, '10', 5, '16');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `totalprice` varchar(255) NOT NULL,
  `orderstatus` varchar(255) NOT NULL,
  `paymentmode` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `uid`, `totalprice`, `orderstatus`, `paymentmode`, `timestamp`) VALUES
(1, 2, '80', 'Order Placed', 'cod', '2017-10-28 12:22:36'),
(2, 2, '42060', 'Order Placed', 'cod', '2017-10-28 12:27:16'),
(3, 6, '21980', 'Cancelled', 'cod', '2017-10-28 14:25:23'),
(4, 6, '12965', 'In Progress', 'cod', '2017-10-28 14:28:29'),
(5, 6, '7750', 'In Progress', 'cod', '2017-11-06 19:40:34');

-- --------------------------------------------------------

--
-- Table structure for table `ordertracking`
--

CREATE TABLE `ordertracking` (
  `id` int(11) NOT NULL,
  `orderid` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ordertracking`
--

INSERT INTO `ordertracking` (`id`, `orderid`, `status`, `message`, `timestamp`) VALUES
(3, 3, 'Cancelled', ' I don&#39;t want this item now.', '2017-10-28 17:54:18'),
(5, 4, 'In Progress', ' Order is in Progress', '2017-10-30 13:31:08'),
(6, 5, 'In Progress', ' Order is in Progress', '2017-11-06 19:45:11');

-- --------------------------------------------------------

--
-- Table structure for table `pay`
--

CREATE TABLE `pay` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `card_number` bigint(20) NOT NULL,
  `card_exp_month` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `card_exp_year` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `item_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `item_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `item_price` float(10,2) NOT NULL,
  `item_price_currency` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `paid_amount` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `paid_amount_currency` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `txn_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `payment_status` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `productname` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pay`
--

INSERT INTO `pay` (`id`, `name`, `email`, `card_number`, `card_exp_month`, `card_exp_year`, `item_name`, `item_number`, `item_price`, `item_price_currency`, `paid_amount`, `paid_amount_currency`, `txn_id`, `payment_status`, `created`, `modified`, `productname`) VALUES
(1, 'ahmed', 'harry@den.com', 4242424242424242, '12', '2021', 'Demo Product', 'PN12345', 10000.00, 'USD', '10000', 'usd', 'txn_1GWQ7bAxaSILLmz4Qj4TMbL3', 'succeeded', '2020-04-10 21:54:26', '2020-04-10 21:54:26', ''),
(2, 'mohid KHAN', 'mohid5762@gmail.com', 4242424242424242, '12', '2021', 'Demo Product', 'PN12345', 10000000.00, 'USD', '10000000', 'usd', 'txn_1GWf9JAxaSILLmz4bQKOWe97', 'succeeded', '2020-04-11 13:57:13', '2020-04-11 13:57:13', ''),
(3, 'mohid KHAN', 'mohid5762@gmail.com', 4242424242424242, '09', '2021', 'Demo Product', '', 50000.00, 'USD', '50000', 'usd', 'txn_1GWg0TAxaSILLmz4BZPaQXmy', 'succeeded', '2020-04-11 14:52:09', '2020-04-11 14:52:09', ''),
(4, 'mohid KHAN', 'mohid5762@gmail.com', 4242424242424242, '12', '2025', 'Demo Product', '', 2858000.00, 'USD', '2858000', 'usd', 'txn_1GYFEPAxaSILLmz4VBwBCet8', 'succeeded', '2020-04-15 22:41:01', '2020-04-15 22:41:01', ''),
(5, 'mohid KHAN', 'vivek@codingcyber.com', 4242424242424242, '12', '2026', 'Demo Product', '', 4147000.00, 'USD', '4147000', 'usd', 'txn_1GYSj8AxaSILLmz49EKpJKHp', 'succeeded', '2020-04-16 13:05:38', '2020-04-16 13:05:38', ''),
(6, 'mehwishnaz', 'saima@yahoo.com', 4242424242424242, '12', '2023', 'Demo Product', '', 11122000.00, 'USD', '11122000', 'usd', 'txn_1GabJZAxaSILLmz4NnBpiF1W', 'succeeded', '2020-04-22 10:40:14', '2020-04-22 10:40:14', ''),
(7, 'mohid KHAN', 'mohid5762@gmail.com', 4242424242424242, '05', '2021', 'Demo Product', '', 11122000.00, 'USD', '11122000', 'usd', 'txn_1Gaby9AxaSILLmz4rdMvcyvi', 'succeeded', '2020-04-22 11:22:00', '2020-04-22 11:22:00', ''),
(8, 'mohid KHAN', 'mohid5762@gmail.com', 4242424242424242, '05', '2021', 'Demo Product', '', 11122000.00, 'USD', '11122000', 'usd', 'txn_1Gac0MAxaSILLmz4jrGMmsJC', 'succeeded', '2020-04-22 11:24:18', '2020-04-22 11:24:18', ''),
(9, 'mehwishnaz', 'mehwish@gmail.com', 4242424242424242, '09', '2021', 'Demo Product', '', 11122000.00, 'USD', '11122000', 'usd', 'txn_1Gac3WAxaSILLmz4IUbm4joM', 'succeeded', '2020-04-22 11:27:33', '2020-04-22 11:27:33', ''),
(10, 'mohid KHAN', 'mohid5762@gmail.com', 4242424242424242, '12', '2021', 'Demo Product', '', 11122000.00, 'USD', '11122000', 'usd', 'txn_1GacGGAxaSILLmz4RTA8fhtE', 'succeeded', '0000-00-00 00:00:00', '2020-04-22 11:40:43', '2020-04-22 11:40:43'),
(11, 'mohid KHAN', 'mohid5762@gmail.com', 4242424242424242, '05', '2023', 'Demo Product', '', 11122000.00, 'USD', '11122000', 'usd', 'txn_1GacLOAxaSILLmz4wi8xStft', 'succeeded', '2020-04-22 11:46:01', '2020-04-22 11:46:01', 'GANDA'),
(12, 'mohid KHAN', 'mohid5762@gmail.com', 4242424242424242, '11', '2020', 'Demo Product', '', 2099000.00, 'USD', '2099000', 'usd', 'txn_1HBIkeAxaSILLmz45q3Hsfdm', 'succeeded', '2020-08-01 16:19:44', '2020-08-01 16:19:44', 'GANDA'),
(13, 'mohid KHAN', 'mohid5762@gmail.com', 4242424242424242, '11', '2020', 'Demo Product', '', 2099000.00, 'USD', '2099000', 'usd', 'txn_1HC0UVAxaSILLmz4LA4JqrQ6', 'succeeded', '2020-08-03 15:01:59', '2020-08-03 15:01:59', 'snipergun');

-- --------------------------------------------------------

--
-- Table structure for table `pay2`
--

CREATE TABLE `pay2` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `card_number` bigint(20) NOT NULL,
  `card_exp_month` varchar(2) NOT NULL,
  `card_exp_year` varchar(5) NOT NULL,
  `item_price` float(10,2) NOT NULL,
  `item_price_currency` varchar(10) NOT NULL,
  `paid_amount` varchar(10) NOT NULL,
  `paid_amount_currency` varchar(10) NOT NULL,
  `txn_id` varchar(50) NOT NULL,
  `payment_status` varchar(25) NOT NULL,
  `productname` varchar(255) NOT NULL,
  `pquantity` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pay2`
--

INSERT INTO `pay2` (`id`, `name`, `email`, `card_number`, `card_exp_month`, `card_exp_year`, `item_price`, `item_price_currency`, `paid_amount`, `paid_amount_currency`, `txn_id`, `payment_status`, `productname`, `pquantity`, `country`, `zip`, `address`, `city`, `phoneno`) VALUES
(1, 'mohid KHAN', 'admin@admin.com', 4242424242424242, '08', '2020', 2099000.00, 'USD', '2099000', 'usd', 'txn_1HC4s6AxaSILLmz4Lyvj3vry', 'succeeded', '', '', '', '', '', '', ''),
(2, 'mohid KHAN', 'mohid5762@gmail.com', 4242424242424242, '09', '2020', 2099000.00, 'USD', '2099000', 'usd', 'txn_1HC54UAxaSILLmz4iZmhSFbX', 'succeeded', '', '2020-08-03 19:55:26', '2020-08-03 19:55:26', '', '', '', ''),
(3, 'mohid KHAN', 'mohid5762@gmail.com', 4242424242424242, '09', '2020', 2099000.00, 'USD', '2099000', 'usd', 'txn_1HC55xAxaSILLmz4jMPNmU2D', 'succeeded', 'Pakistan', '2020-08-03 19:56:57', '2020-08-03 19:56:57', '', '', '', ''),
(4, 'mohid KHAN', 'mohid5762@gmail.com', 4242424242424242, '09', '2020', 2099000.00, 'USD', '2099000', 'usd', 'txn_1HC57UAxaSILLmz49sZ4bywz', 'succeeded', 'Pakistan', '2020-08-03 19:58:32', '2020-08-03 19:58:32', '', '', '', ''),
(5, 'mohid KHAN', 'mohid5762@gmail.com', 4242424242424242, '09', '2020', 2099000.00, 'USD', '2099000', 'usd', 'txn_1HC5AQAxaSILLmz4BIuuc3aM', 'succeeded', 'Pakistan', '2020-08-03 20:01:34', '2020-08-03 20:01:34', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `pay3`
--

CREATE TABLE `pay3` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `productname` varchar(255) NOT NULL,
  `card_number` varchar(255) NOT NULL,
  `card_exp_month` varchar(255) NOT NULL,
  `card_exp_year` varchar(255) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_number` varchar(50) NOT NULL,
  `item_price` float(10,2) NOT NULL,
  `item_price_currency` varchar(10) NOT NULL,
  `paid_amount` varchar(10) NOT NULL,
  `paid_amount_currency` varchar(10) NOT NULL,
  `txn_id` varchar(50) NOT NULL,
  `payment_status` varchar(25) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `country` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `cvc` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pay3`
--

INSERT INTO `pay3` (`id`, `name`, `email`, `productname`, `card_number`, `card_exp_month`, `card_exp_year`, `item_name`, `item_number`, `item_price`, `item_price_currency`, `paid_amount`, `paid_amount_currency`, `txn_id`, `payment_status`, `created`, `modified`, `country`, `phone`, `zip`, `address`, `state`, `cvc`) VALUES
(1, 'mohid KHAN', 'saima@yahoo.com', 'GANDA', '4242424242424242', '11', 'Demo Product', '2020', '', 2099000.00, 'USD', '2099000', 'usd', 'txn_1HC6gdAxaSILLmz4xwgXugPV', 'succeeded', '0000-00-00 00:00:00', '2020-08-03 21:38:55', '2020-08-03 21:38:55', '', '', '', '', ''),
(2, 'mohid KHAN', 'saima@yahoo.com', 'GANDA', '11', 'Demo Product', '2020', '2099000', '', 0.00, '2099000', 'usd', 'txn_1HC6iH', 'succeeded', 'Pakistan', '2020-08-03 21:40:36', '2020-08-03 21:40:36', '4242424242424242', '', '', '', '', ''),
(3, 'mohid KHAN', 'saima@yahoo.com', 'GANDA', '4242424242424242', '11', 'Demo Product', '2020', '', 2099000.00, 'USD', '2099000', 'usd', 'txn_1HC6jjAxaSILLmz47oe5Wcrv', 'succeeded', '2020-08-03 21:42:07', '2020-08-03 21:42:07', 'Pakistan', '', '', '', '', ''),
(4, 'mohid KHAN', 'saima@yahoo.com', 'GANDA', '4242424242424242', '11', 'Demo Product', '2020', '', 2099000.00, 'USD', '2099000', 'usd', 'txn_1HC6vFAxaSILLmz4VfWfK1VL', 'succeeded', '2020-08-03 21:54:01', '2020-08-03 21:54:01', 'Pakistan', '03095934047', '44000', 'house no 11 E block E street 1 Soan garden', 'Islamabad', ''),
(5, 'mohid KHAN', 'saima@yahoo.com', 'GANDA', '4242424242424242', '11', 'Demo Product', '2020', '', 2099000.00, 'USD', '2099000', 'usd', 'txn_1HC748AxaSILLmz4LXwTxEKF', 'succeeded', '2020-08-03 22:03:12', '2020-08-03 22:03:12', 'Pakistan', '123', '44000', 'house no 11 E block E street 1 Soan garden', 'Islamabad', '03095934047'),
(6, 'mohid KHAN', 'saima@yahoo.com', 'GANDA', '4242424242424242', '11', 'Demo Product', '2020', '', 2099000.00, 'USD', '2099000', 'usd', 'txn_1HC75sAxaSILLmz4CHuIJfFO', 'succeeded', '2020-08-03 22:04:59', '2020-08-03 22:04:59', 'Pakistan', '03095934047', '44000', 'house no 11 E block E street 1 Soan garden', 'Islamabad', '123'),
(7, 'mohid KHAN', 'saima@yahoo.com', 'GANDA', '4242424242424242', '11', 'Demo Product', '2020', '', 2099000.00, 'USD', '2099000', 'usd', 'txn_1HC7ERAxaSILLmz4o0K9yJeU', 'succeeded', '2020-08-03 22:13:50', '2020-08-03 22:13:50', 'Pakistan', '03095934047', '44000', 'house no 11 E block E street 1 Soan garden', 'Islamabad', '123'),
(8, 'mohid KHAN', 'vivek@codingcyber.com', 'GANDA', '4242424242424242', '11', 'Demo Product', '2020', '', 2099000.00, 'USD', '2099000', 'usd', 'txn_1HCTbuAxaSILLmz47OFBpKyl', 'succeeded', '2020-08-04 22:07:33', '2020-08-04 22:07:33', 'Pakistan', '03095934047', '44000', 'house no 11 E block E street 1 Soan garden', 'Islamabad', '123'),
(9, 'mohid KHAN', 'vivek@codingcyber.com', 'GANDA', '4242424242424242', '11', 'Demo Product', '2020', '', 2099000.00, 'USD', '2099000', 'usd', 'txn_1HCTj3AxaSILLmz4tLGwD718', 'succeeded', '2020-08-04 22:14:56', '2020-08-04 22:14:56', 'Pakistan', '03095934047', '44000', 'house no 11 E block E street 1 Soan garden', 'Islamabad', '123'),
(10, 'mohid KHAN', 'vivek@codingcyber.com', 'GANDA', '4242424242424242', '11', 'Demo Product', '2020', '', 2099000.00, 'USD', '2099000', 'usd', 'txn_1HCTkTAxaSILLmz40wFFBFir', 'succeeded', '2020-08-04 22:16:31', '2020-08-04 22:16:31', 'Pakistan', '03095934047', '44000', 'house no 11 E block E street 1 Soan garden', 'Islamabad', '123'),
(11, 'Mohid Naz', 'harry@den.com', '  Canon EOS 1300D 18MP(3)  General Knowledge 20(6)  Think and Grow Rich(1)orange(56)', '4242424242424242', '11', 'Demo Product', '2020', '', 11914100.00, 'USD', '11914100', 'usd', 'txn_1HCoE5AxaSILLmz4XVXBYbLG', 'succeeded', '2020-08-05 20:08:21', '2020-08-05 20:08:21', 'California', '03095934047', '44000', 'house no 11 E block E street 1 Soan garden', 'Islamabad', '123'),
(12, 'mohid KHAN', 'admin@admin.com', '  General Knowledge 20(6)', '4242424242424242', '08', '2020', 'Demo Product', '', 9600.00, 'USD', '9600', 'usd', 'txn_1HCrEFAxaSILLmz4wh9ekPz8', 'succeeded', '2020-08-05 23:20:42', '2020-08-05 23:20:42', 'Pakistan', '03095934047', '44000', 'house no 11 E block E street 1 Soan garden', 'Islamabad', '123'),
(13, 'mohid naz', 'mohidnaz@gmail.com', '  Canon EOS 1300D 18MP(1)', '4242424242424242', '01', '2021', 'Demo Product', '', 2099000.00, 'USD', '2099000', 'usd', 'txn_1HFFV4AxaSILLmz4DlKhtL14', 'succeeded', '2020-08-12 13:39:59', '2020-08-12 13:39:59', 'Pakistan', '03328758643', '44000', 'house no 11 E block E street 1 Soan garden', 'Islamabad', '123'),
(14, 'mohid naz', 'mohidnaz@gmail.com', '  Canon EOS 1300D 18MP(1)', '4242424242424242', '01', '2021', 'Demo Product', '', 2099000.00, 'USD', '2099000', 'usd', 'txn_1HFFYpAxaSILLmz4Y2yxDfPq', 'succeeded', '2020-08-12 13:43:52', '2020-08-12 13:43:52', 'Pakistan', '03328758643', '44000', 'house no 11 E block E street 1 Soan garden', 'Islamabad', '123'),
(15, 'mohid naz', 'mohidnaz@gmail.com', '  Canon EOS 1300D 18MP(1)', '4242424242424242', '01', '2021', 'Demo Product', '', 2099000.00, 'USD', '2099000', 'usd', 'txn_1HFFcMAxaSILLmz4eypdcGrM', 'succeeded', '2020-08-12 13:47:31', '2020-08-12 13:47:31', 'Pakistan', '03328758643', '44000', 'house no 11 E block E street 1 Soan garden', 'Islamabad', '123'),
(16, 'mohid naz', 'mohidnaz@gmail.com', '  Canon EOS 1300D 18MP(1)', '4242424242424242', '01', '2021', 'Demo Product', '', 2099000.00, 'USD', '2099000', 'usd', 'txn_1HFFh9AxaSILLmz43SBcFfPS', 'succeeded', '2020-08-12 13:52:27', '2020-08-12 13:52:27', 'Pakistan', '03328758643', '44000', 'house no 11 E block E street 1 Soan garden', 'Islamabad', '123');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `catid` int(11) NOT NULL,
  `price` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `catid`, `price`, `thumb`, `description`) VALUES
(1, 'Canon EOS 1300D 18MP Digital SLR Camera (Black) with 18-55mm ISII Lens, 16GB Card and Carry Case', 2, '20990', 'uploads/Canon EOS 200D 24 2MP.jpg', 'The EOS 1300D packs in all the fun of photography, which is why we recommend it to users looking for their very first EOS DSLR camera. It uses an 18-megapixel APS-C size sensor and the DIGIC 4+ image processor'),
(2, 'Sony DSC W830 Cyber-shot 20.1 MP Point and Shoot Camera (Black) with 8x Optical Zoom, Memory Card and Camera Case', 2, '7590', 'uploads/Sony Alpha a6000 Mirrorless Digital.jpg', 'The Sony DSC W830 Cyber-shot 20.1 MP Point and Shoot Camera (Black) with 8x Optical Zoom is a powerful camera full of features that put it at par with any professional DSLR. It is packed with a super HAD CCD sensor that comes with 20.1 effective megapixel'),
(18, 'Sony Cyber-shot DSC-H300/BC E32 point & Shoot Digital camera ', 2, '12890', 'uploads/Sony Alpha ILCA-77M2Q 24 3MP.jpg', 'The High zoom camera Sony Cyber-shot H300, with a powerful 35x optical zoom, brings your subject to you for beautiful, precise pictures. A 20.1MP sensor, HD video and creative features, let you capture detailed images and movies with ease. A DSLR-style bo'),
(19, 'General Knowledge 2018', 3, '16', 'uploads/General Knowledge 2018.jpg', 'An editorial team of highly skilled professionals at Arihant, works hand in glove to ensure that the students receive the best and accurate content through our books. From inception till the book comes out from print, the whole team comprising of authors,'),
(20, 'The Power of your Subconscious Mind', 3, '99', 'uploads/The Power of your Subconscious Mind.jpg', 'It\'s a very good n very useful book n it should be read by each n every one ...to knw the things that are not aware and know about the mind power .. Super duper book --ByAmazon Customeron 19 March 2017'),
(21, 'Think and Grow Rich', 3, '75', 'uploads/Think and Grow Rich.jpg', 'An American journalist, lecturer and author, Napoleon Hill is one of the earliest producers of \'personal-success literature . As an author of self-help books, Hill has always abided by and promoted principle of intense and burning passion being the sole k'),
(22, 'Orange', 4, '1000', 'uploads/download.jpg', 'This isorange and its  has orange color as well it look like someone is sitting infront of me .');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `review` text NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `pid`, `uid`, `review`, `timestamp`) VALUES
(1, 1, 6, 'It&#39;s an awesome Product...', '2017-10-30 15:18:42');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `timestamp`) VALUES
(1, 'vivek@codingcyber.com', '26e0eca228b42a520565415246513c0d', '2017-10-27 12:05:10'),
(2, 'vivek1@codingcyber.com', '$2y$10$cMzHNUFGKma96MywHmVMbekuJZb1tSNLsevHzLnSRbcRicQVhEC6a', '2017-10-27 12:24:25'),
(6, 'vivek2@codingcyber.com', '$2y$10$apI7l.1wAS5pgbG4YfMrN.jNd5T3XmhecFuSV2M6UNdoUHImPXNxm', '2017-10-27 12:28:20'),
(7, 'junaid@gmail.com', '$2y$10$QqsJ8w06HnVj0aeE3uJkDOnW06gWHso06mseqHtBR10k4B0my/tR6', '2020-04-22 10:52:22'),
(8, 'mohid5762@gmail.com', '$2y$10$PEWkH8zBu3j1esNZeVxtVuQeKhuvdI/4lDyvYiTxIz/25FyxZoK9m', '2020-07-31 16:06:46'),
(9, 'saima@yahoo.com', '$2y$10$I0Jc4YSwt3PRNWeep.OFNefmiuWVCHjlv43VNfZSs.HulaOclOovO', '2020-08-03 15:00:25'),
(10, 'harry@den.com', '$2y$10$fClL80IVtSxXNHb5aD/Exei38zKZ1IDHt8W6u9tdVB/7Y.KzQ4YeW', '2020-08-05 20:04:52');

-- --------------------------------------------------------

--
-- Table structure for table `usersmeta`
--

CREATE TABLE `usersmeta` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usersmeta`
--

INSERT INTO `usersmeta` (`id`, `uid`, `firstname`, `lastname`, `company`, `address1`, `address2`, `city`, `state`, `country`, `zip`, `mobile`) VALUES
(1, 2, 'Vivek', 'V', 'Coding Cyber', 'Hyd', 'Hyd', 'Hyderabad', 'Telangana', '', '500060', ''),
(2, 6, 'Vivek', 'Vengala', 'Coding Cyber', '#201', 'DSNR', 'Hyderabad', 'Telangana', '', '500060', '9876543211');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `pid`, `uid`, `timestamp`) VALUES
(1, 1, 6, '2017-10-30 16:36:45'),
(2, 2, 6, '2017-10-30 16:38:07'),
(3, 21, 6, '2017-11-06 19:42:35');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderitems`
--
ALTER TABLE `orderitems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ordertracking`
--
ALTER TABLE `ordertracking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pay`
--
ALTER TABLE `pay`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pay2`
--
ALTER TABLE `pay2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pay3`
--
ALTER TABLE `pay3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `usersmeta`
--
ALTER TABLE `usersmeta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orderitems`
--
ALTER TABLE `orderitems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `ordertracking`
--
ALTER TABLE `ordertracking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `pay`
--
ALTER TABLE `pay`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `pay2`
--
ALTER TABLE `pay2`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `pay3`
--
ALTER TABLE `pay3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `usersmeta`
--
ALTER TABLE `usersmeta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
