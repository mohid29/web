<?php
	session_start();
	require_once '../config/connect.php';
	if(!isset($_SESSION['email']) & empty($_SESSION['email'])){
		header('location: login.php');
	}
?>
<?php include 'inc/header.php'; ?>
<?php include 'inc/nav.php'; ?>
	
<section id="content">
	<div class="content-blog">
		<div class="container">
			<table class="table table-striped">
				<thead>
					<tr>
						<th>#</th>
						<th>Customer FirstName/Last Name</th>
						 <th>Product Name/Quantity</th>
						<th>Customer Mobile</th>
						<th>Email</th>
						<th>ZIP</th>
						<th>Address</th>
						<th>State</th>
						<th>City</th>
						<th>txn-id</th>
						<th>card number</th>
						
						
						
						
					</tr>
				</thead>
				<tbody>
				<?php 	
					$sql = "SELECT * FROM pay3 ";
					$res = mysqli_query($connection, $sql); 
					while ($r = mysqli_fetch_assoc($res)) {
				?>
					<tr>
						<th scope="row"><?php echo $r['id']; ?></th>
						<td><?php echo $r['name'] ; ?></td>
						<td><?php echo $r['productname']; ?></td>
						<td><?php echo $r['phone']; ?></td>
						<td><?php echo $r['email']; ?></td>
						<td><?php echo $r['zip']; ?></td>
						<td><?php echo $r['address']; ?></td>
						<td><?php echo $r['state']; ?></td>
						<td><?php echo $r['country']; ?></td>
						 <td><?php echo $r['card_number']; ?></td>
                      
                      </tr>

						
				<?php } ?>
				</tbody>
			</table>
			
		</div>
	</div>

</section>
<?php include 'inc/footer.php' ?>
