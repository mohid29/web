 <form action="payment.php" method="POST" id="paymentFrm">
            <center>
            <div class="form-group">
                <label>NAME</label>
                <input type="text" name="name" id="name" placeholder="Enter name" required="" autofocus="">
            </div>
            


              <div class="form-group">
                <label>ProductNAME</label>
                <input type="text" name="productname" id="productname" placeholder="Enter name" required="" autofocus="">
            </div>
            
           
                        



            <div class="form-group">
                <label>EMAIL</label>
                <input type="email" name="email" id="email" placeholder="Enter email" required="">
            </div>
            <div class="form-group">
                <label>CARD NUMBER</label>
                <input type="text" name="card_number" id="card_number" placeholder="1234 1234 1234 1234" autocomplete="off" required="">
            </div>
            <div class="row">
                <div class="left">
                    <div class="form-group">
                        <label>EXPIRY DATE</label>
                        <div class="col-1">
                            <input type="text" name="card_exp_month" id="card_exp_month" placeholder="MM" required="">
                        </div>
                        <div class="col-2">
                            <input type="text" name="card_exp_year" id="card_exp_year" placeholder="YYYY" required="">
                        </div>
                    </div>
                </div>
                <div class="right">
                    <div class="form-group">
                        <label>CVC CODE</label>
                        <input type="text" name="card_cvc" id="card_cvc" placeholder="CVC" autocomplete="off" required="">
                    </div>
                </div>
            </div>


              <div class="clearfix space10"></div>
                            <label>Products with Quantity</label>
                            <input name="productname" class="form-control" placeholder="ProductName(Quantity) example: SonyCamera(1)"  type="text">
                            <div class="clearfix space10"></div>

           
            <button type="submit" class="btn btn-success" id="payBtn">Submit Payment</button>
        </center>
        </form>