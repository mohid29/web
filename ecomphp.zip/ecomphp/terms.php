<?php 
session_start();
require_once 'config/connect.php';
include 'inc/header.php'; ?>
<?php include 'inc/nav.php'; ?>



<section id="content">
		<div class="content-blog">
			<div class="container">
				<div class="row">
					<div class="page_header text-center">
						<h2>MJSS COLLECTION</h2>
						<p>Terms & Condition</p>
					</div>
					<div class="col-md-12">

						<body> 

                        <h1>Return Policy </h1>

                        
                           <p> ALL SALES ARE FINAL. Returns will not be accepted without prior authorization and must be reported within 7 days of the receipt of merchandise. Items must be in original packaging and must not be used, worn, marked, packaged with other materials or customer labels. NO cash returns will be given, no exceptions. NO merchandise will be accepted for return/exchange if there is nothing wrong with item beyond the 7 days of when order was placed. All shipping and handling fees are NOT refundable. If wrong merchandise is received, please contact us immediately or within 7 days or receipt. Store credit will be valid for 30 days. Once 30 days have lapsed, store credit becomes null and void. MJSS COLLECTIONS does not extend any form of credit (i.e. 30 day net).</p>
</body>



                          <body> 

                        <h1></h1>

                        
                           <p> </p>
</body>
						

								
							</div>
						</div>
						<div class="clearfix"></div>
						<!-- Pagination -->
						
						<!-- End Pagination -->
					</div>
				</div>
			</div>
		</div>
	</section>




<?php include 'inc/footer.php' ?>