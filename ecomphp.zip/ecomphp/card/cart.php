<?php 
session_start();
require_once 'config/connect.php';

include 'inc/nav.php'; 
//$cart = (isset($_POST['cart']) ? $_POST['cart'] : '');

$itemName = "Demo Product"; 
$currency = "USD"; 
$itemPrice= $total  +($cartr['price']*$value['quantity']);

$cart = $_SESSION['cart'];
?>

	
	