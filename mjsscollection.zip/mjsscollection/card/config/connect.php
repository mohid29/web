<?php



define('STRIPE_API_KEY', 'sk_test_EXmjM5Fo2euWqECpqMi1xr1C0095u604LE'); 
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_kiCWsC3rhdEFdJOHhcUaYfDo00kt2t8Zea'); 
  

$connection = mysqli_connect('localhost', 'root', '', 'ecomphp');
if(!$connection){
	echo "Error: Unable to connect to MySQL." . PHP_EOL;
    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    exit;
}
?>

