<?php 
session_start();
require_once 'config/connect.php';
include 'inc/header.php'; ?>
<?php include 'inc/nav.php'; ?>



<section id="content">
		<div class="content-blog">
			<div class="container">
				<div class="row">
					<div class="page_header text-center">
						<h2>MJSS COLLECTION</h2>
						<p>Contact Us</p>
					</div>
					<div class="col-md-12">
<body>
						<div> 

							<center>     
								        <a href="mailto:mjssenterprise@gmail.com">Email : mjssenterprise@gmail.com </a>

								        <p>Send us your Query Anytime! </p>
				  				

							</center> </div>

							<center>  

							
								<a href="tel:+1(517)2135003">Phone: +1(517)2135003</a>
				  				
                                  

							</center>

							<center>   
                            
							 <a href="">Address:</a>				
				  			

							</center>

							<center>    <a href="">Working Days: </a>				
				  			

							</center>

								        


                         


</body>



                          <body> 

                        <h1></h1>

                        
                           <p> </p>
</body>
						

								
							</div>
						</div>
						<div class="clearfix"></div>
						<!-- Pagination -->
						
						<!-- End Pagination -->
					</div>
				</div>
			</div>
		</div>
	</section>




<?php include 'inc/footer.php' ?>