<?php 

// Include configuration file  
require_once 'card/config2/connect.php'; 

include 'inc2/header.php';



 ?>

 <?php require_once 'cart2.php'; ?>

<head>
<script src="https://js.stripe.com/v2/"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>


<script>
// Set your publishable key
Stripe.setPublishableKey('<?php echo STRIPE_PUBLISHABLE_KEY; ?>');

// Callback to handle the response from stripe
function stripeResponseHandler(status, response) {
    if (response.error) {
        // Enable the submit button
        $('#payBtn').removeAttr("disabled");
        // Display the errors on the form
        $(".payment-status").html('<p>'+response.error.message+'</p>');
    } else {
        var form$ = $("#paymentFrm");
        // Get token id
        var token = response.id;
        // Insert the token into the form
        form$.append("<input type='hidden' name='stripeToken' value='" + token + "' />");
        // Submit form to the server
        form$.get(0).submit();
    }
}

$(document).ready(function() {
    // On form submit
    $("#paymentFrm").submit(function() {
        // Disable the submit button to prevent repeated clicks
        $('#payBtn').attr("disabled", "disabled");
        
        // Create single-use token to charge the user
        Stripe.createToken({
            number: $('#card_number').val(),
            exp_month: $('#card_exp_month').val(),
            exp_year: $('#card_exp_year').val(),
            cvc: $('#card_cvc').val()
        }, stripeResponseHandler);
        
        // Submit from callback
        return false;
    });
});
</script>

</head>
<body> 
<div class="panel">
    <div class="panel-heading">
        <center>
 
</center>
        
        <!-- Product Info -->
        <center>
        <h3 class="panel-title">Charge <?php echo '$'.$itemPrice; ?> </h3>
        </center>
   




    </div>
    <div class="panel-body">
        <!-- Display errors returned by createToken -->
        <div class="payment-status"></div>
        
        <!-- Payment form -->
       <form action="payment.php" method="POST" id="paymentFrm">
<div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <div class="billing-details">
                       
                        <div class="space30">Payment Through Credit Card</div>
                           
                            <div class="clearfix space20"></div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label> Name </label>
                                    <input name="name" class="form-control" id="name"  required="" autofocus=""placeholder="Name" type="text">
                                </div>
                               
                            </div>
                            <div class="clearfix space20"></div>
                            <label>Products with Quantity</label>
                            <input name="productname" class="form-control" placeholder="ProductName(Quantity) example: SonyCamera(1)" required="" autofocus="" id="productname">
                            <div class="clearfix space20"></div>

                            <div class="form-group">
                <label>EMAIL</label>
                <input type="email" name="email" id="email" placeholder="Enter email" required="">
            </div>


                <div class="form-group">
                <label>CARD NUMBER</label>
                <input type="text" name="card_number" id="card_number" placeholder="1234 1234 1234 1234" autocomplete="off" required="">
            </div>
            <div class="row">
                <div class="left">
                    <div class="form-group">
                        <label>EXPIRY DATE</label>
                        <div class="col-1">
                            <input type="text" name="card_exp_month" id="card_exp_month" placeholder="MM" required="">
                        </div>
                        <div class="col-2">
                            <input type="text" name="card_exp_year" id="card_exp_year" placeholder="YYYY" required="">
                        </div>
                    </div>
                </div>
               

            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                        <label>CVC CODE</label>
                        <input type="text" name="card_cvc" id="card_cvc" placeholder="CVC" autocomplete="off" required="">
                    </div>
                                   
                                </div>
                                <div class="col-md-4">
                                   
                                </div>
                                <div class="col-md-4">
                                   
                                </div>
                            </div>
                           
                           
                
            </div>
            
            
            
            
                        
<center> 
<button type="submit" class="btn btn-success" id="payBtn">Submit Payment</button>

</center>   
  

                        
</form>

                        
        
    </div>
</div>

</body>

<?php  include 'inc/footer.php'; ?> 