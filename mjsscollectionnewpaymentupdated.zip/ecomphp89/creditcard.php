<?php 
session_start();
require_once 'config/connect.php';
include 'inc/header.php'; 
include 'inc/nav.php'; 
//$cart = (isset($_POST['cart']) ? $_POST['cart'] : '');


$cart = $_SESSION['cart'];
?>
 
<?php

  $name = $_POST['name']; 
 $productname = $_POST['productname']; 
    $email = $_POST['email']; 
    $card_number = $_POST['card_number']; 
    $card_exp_month = $_POST['card_exp_month']; 
    $card_exp_year = $_POST['card_exp_year']; 
    $card_cvc = $_POST['card_cvc']; 
    $phone =$_POST['phone'];
    $address =$_POST['address'];
    $zip=$_POST['zip'];
    $state =$_POST['state'];
    $card_cvc =$_POST['card_cvc'];
    
 $sql = "INSERT INTO pay3(name,email,productname,phone,cvc,zip,address,state,country,card_number,card_exp_month,card_exp_year,item_name,item_price,item_price_currency,paid_amount,paid_amount_currency,txn_id,payment_status,created,modified) VALUES('".$name."','".$email."','".$productname."','".$phone."','".$card_cvc."','".$zip."','".$address."','".$state."','".$country."','".$card_number."','".$card_exp_month."','".$card_exp_year."','".$itemName."','".$itemPrice."','".$currency."','".$paidAmount."','".$paidCurrency."','".$transactionID."','".$payment_status."',NOW(),NOW())"; 
        $insert = $connection->query($sql); 
        $payment_id = $connection->insert_id; 

?>

<head>




</head>
<body> 
<div class="panel">
    <div class="panel-heading">
        <center>
 
</center>
        
        <!-- Product Info -->
      



    </div>
    <div class="panel-body">
        <!-- Display errors returned by createToken -->
        <div class="payment-status"></div>
        
        <!-- Payment form -->
        <form action="index2.php" method="POST" id="paymentFrm">
            <center>
            <div class="form-group">
                <label>NAME</label>
                <input type="text" name="name" id="name" placeholder="Enter name" required="" autofocus="">
            </div>
            


              <div class="form-group">
                <label>ProductNAME</label>
                <input type="text" name="productname" id="productname" placeholder="Enter name" required="" autofocus="">
            </div>
              <div class="form-group">
                <label>Country NAME</label>
                <input type="text" name="country" id="country" placeholder="Enter country name" required="" autofocus="">
            </div>
              <div class="form-group">
                <label>Address</label>
                <input type="text" name="address" id="address" placeholder="Enter your Address" required="" autofocus="">
            </div>
              <div class="form-group">
                <label>ZIP</label>
                <input type="text" name="zip" id="zip" placeholder="Enter ZIP" required="" autofocus="">
            </div>
              <div class="form-group">
                <label>Phone number</label>
                <input type="text" name="phone" id="phone" placeholder="Enter Phone Number" required="" autofocus="">
            </div>
            <div class="form-group">
                <label>state</label>
                <input type="text" name="state" id="state" placeholder="Enter State name" required="" autofocus="">
            </div>
            <div class="form-group">
                <label>EMAIL</label>
                <input type="email" name="email" id="email" placeholder="Enter email" required="">
            </div>
           

           
            <button type="submit" class="btn btn-success" id="payBtn">Submit Payment</button>
        </center>
        </form>
    </div>
</div>

</body>

<?php  include 'inc/footer.php'; ?> 