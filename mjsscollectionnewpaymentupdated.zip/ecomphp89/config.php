<?php
require_once('vendor/autoload.php');

$stripe = array(
  "secret_key"      => "sk_test_EXmjM5Fo2euWqECpqMi1xr1C0095u604LE",
  "publishable_key" => "pk_test_kiCWsC3rhdEFdJOHhcUaYfDo00kt2t8Zea"
);

\Stripe\Stripe::setApiKey($stripe['secret_key']);
?>